package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DormitoryDao;
import dao.UserDao;
import entity.User;


/**
 * Servlet implementation class LoginPost
 */
public class LoginPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname=request.getParameter("uname");
		System.out.println(uname);
		String pwd=request.getParameter("pwd");
		UserDao dao=new UserDao();
		User user=dao.ByUserName(uname);
		System.out.print(user.getPwd());
		if(user==null){
			response.sendRedirect("denglu.jsp");
		}else if(!user.getPwd().equals(pwd)){
			response.sendRedirect("denglu.jsp");
		}else{
			HttpSession session=request.getSession();
			session.setAttribute("uname", user.getUname());
			request.getRequestDispatcher("MainPost").forward(request, response);
		}
		
	}

}
