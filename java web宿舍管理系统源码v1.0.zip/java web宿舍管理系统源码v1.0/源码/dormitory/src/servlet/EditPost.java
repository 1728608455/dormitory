package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DormitoryDao;
import entity.Dormitory;

/**
 * Servlet implementation class EditPost
 */
public class EditPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("更改");
		request.setCharacterEncoding("utf-8");
		int no=Integer.parseInt(request.getParameter("no"));
		String captain=request.getParameter("captain");
		int amount=Integer.parseInt(request.getParameter("amount"));
		String aunt=request.getParameter("aunt");
		String address=request.getParameter("address");
		Dormitory dormitory=new Dormitory();
		dormitory.setNo(no);
		dormitory.setCaptain(captain);
		dormitory.setAmount(amount);
		dormitory.setAunt(aunt);
		dormitory.setAddress(address);
		DormitoryDao dao=new DormitoryDao();
		boolean b=dao.updateByNo(dormitory, no);
		System.out.println("ok"+b);
		if(b==true){
			request.getRequestDispatcher("MainPost").forward(request, response);
		}else{
			response.sendRedirect("update.jsp");
		}
		
	}

}
