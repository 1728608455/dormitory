package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import dao.UserDao;
import entity.User;
public class UserDao  {
	
	public User ByUserName(String uname) {
		Connection con=null;
		try{
			con=DBConnection.getConnection();
			String sql="select * from user where uname=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, uname);
			ResultSet rs=pst.executeQuery();
			if(rs.next()==false){
				return null;
			}else{
				User user=new User();
				user.setId(rs.getInt("id"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
				return user;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(con);
		}
		
	}
	
	public static void main(String[] args) {
		UserDao u=new UserDao();
		User user=u.ByUserName("admin");
		System.out.println(user.getPwd());
	}	
}
