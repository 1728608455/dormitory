package dao;

import java.sql.*;


import java.util.ArrayList;
import java.util.List;

import entity.Dormitory;
//#85949d
//#2192d3
public class DormitoryDao {
	public List<Dormitory> query(){
		Connection c=null;   
		List<Dormitory> list =new ArrayList<Dormitory>();
		try{
			c=DBConnection.getConnection();
			String sql="select * from Dormitory";
			PreparedStatement pst=c.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				Dormitory dormitory =new Dormitory();
				dormitory.setNo(rs.getInt("No"));
				dormitory.setCaptain(rs.getString("captain"));
				dormitory.setAmount(rs.getInt("amount"));
				dormitory.setAunt(rs.getString("aunt"));
				dormitory.setAddress(rs.getString("address"));
				list.add(dormitory);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean insert(Dormitory dormitory){
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="insert into Dormitory(no,captain,amount,aunt,address) values (?,?,?,?,?)";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,dormitory.getNo());
			pst.setString (2,dormitory.getCaptain());
			pst.setInt(3,dormitory.getAmount());
			pst.setString(4,dormitory.getAunt());
			pst.setString(5,dormitory.getAddress());
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public Dormitory query(int no){
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="select * from Dormitory where no=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,no);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				Dormitory dormitory=new Dormitory();
				dormitory.setNo(rs.getInt("no"));
				dormitory.setCaptain(rs.getString("captain"));
				dormitory.setAmount(rs.getInt("amount"));
				dormitory.setAunt(rs.getString("aunt"));
				dormitory.setAddress(rs.getString("address"));
				return dormitory;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean deleteByNo(int no){
		Connection c=null;
		try{
			c=DBConnection.getConnection();
			String sql="delete from Dormitory where no=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,no);
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
	}
	public boolean updateByNo(Dormitory dormitory,int no){
		 	Connection c=null;
		 	try{
		 		c=DBConnection.getConnection();
				String sql="update dormitory set no=?,captain=?,amount=?,aunt=?,address=? where no=?";
				PreparedStatement pst=c.prepareStatement(sql);
				pst.setInt(1, dormitory.getNo());
				pst.setString(2, dormitory.getCaptain());
				pst.setInt(3, dormitory.getAmount());
				pst.setString(4, dormitory.getAunt());
				pst.setString(5, dormitory.getAddress());	
				pst.setInt(6,no);
				pst.execute();	
				return true;		 	
		 	}catch(Exception e){
		 		e.printStackTrace();
		 		return false;
		 	}finally{
		 		DBConnection.closeConnection(c);
		 	}
	}
	
	
		public static void main(String args[]){
		DormitoryDao dao=new DormitoryDao();
		List<Dormitory> list=dao.query();
		System.out.println("长度是"+list.size());
		//DormitoryDao dao=new DormitoryDao();
		Dormitory dormitory =new Dormitory();
	
		//boolean b=Dormitorydao.update(Dormitory,11);
		boolean b=dao.insert(dormitory);
		//System.out.println("update  "+b);*/
		//Dormitory Dormitory=dao.query(1);
		
		//boolean c=dao.update(Dormitory, 17);
		
		//boolean c=dao.delete(10);
		System.out.print(b);
	
	}
}
