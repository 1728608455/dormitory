package entity;

public class Dormitory {
	private Integer no;
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getCaptain() {
		return captain;
	}
	public void setCaptain(String captain) {
		this.captain = captain;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getAunt() {
		return aunt;
	}
	public void setAunt(String aunt) {
		this.aunt = aunt;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	private String captain;
	private Integer amount;
	private String aunt;
	private String address;
}
